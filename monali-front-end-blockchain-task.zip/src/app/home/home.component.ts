import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';
import tokencontract3RABI from '../Abis/tokencontractABI.json'
import tokencontract4RABI from '../Abis/tokencontractBABI.json'
import Web3 from 'Web3';
import {ServiceService} from '../service.service'
// import particles from '../../assets/particles.json'
import WalletConnect from '@walletconnect/client';
import WalletConnectProvider from "@walletconnect/web3-provider";
import Swal from 'sweetalert2';
import { NgNavigatorShareService } from 'ng-navigator-share'

declare let window: any
// import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {



  private ngNavigatorShareService: NgNavigatorShareService;
  addressForm: FormGroup ;
  web3:any
  contract:any
  address:any;
  contracttokenB:any
  show:boolean=false
  rtokenBalance:number =0
  tokenBalance:number =0
  selctedtoken:any
  selectedtokencontract:any
//particless



  constructor(private _formBuilder: FormBuilder,private service:ServiceService,ngNavigatorShareService: NgNavigatorShareService){
    this.addressForm = this._formBuilder.group({
      
      transferto: ['', [Validators.required]],
      amount: ['', [Validators.required]],
    })
    this.ngNavigatorShareService = ngNavigatorShareService;
  }
  onAddress(value:any){
    console.log(value.target.value)

  }
  // getSelectedValue(value:any){
  
  //   // Prints selected value
  //   console.log(value);
  //   console.log('hii')
  //   this.selctedtoken =value
  // }
  async send(value:any){
    console.log('selected',this.selctedtoken)
    console.log(value)
    console.log(this.addressForm.value.transferto)
    console.log(this.addressForm.value.amount)
  //  await  this.approve(this.addressForm.value.amount,value)
  this.address=localStorage.getItem('address')
  // console.log(token,'token')
  if(value ==0x9cA9A8f02e77569A69babAF0dDe0987BE7b525D5){
    this.selectedtokencontract = new this.web3.eth.Contract(tokencontract4RABI,value,{from:this.address})
  }
  else if(value ==0xc1D95464215F484027D58e5f6F700D3f1C167fc9){
    this.selectedtokencontract = new this.web3.eth.Contract(tokencontract3RABI,value,{from:this.address})
  }else{
    alert("enter valid Token Address")
  }
//  var ramount =  this.web3.utils.toHex(String(this.web3.utils.fromWei(Number(amount), 'ether')))
var ramount =  this.web3.utils.toWei(String(this.addressForm.value.amount), 'ether')
 var rtoken= this.selectedtokencontract.methods.transfer(this.addressForm.value.transferto,ramount).encodeABI()
 var istrustwallet =localStorage.getItem('istrustwallet');
 if(istrustwallet == 'true'){
  const provider1 = JSON.parse(JSON.stringify(localStorage.getItem('walletconnect')));
  try{
    const connector = new WalletConnect({
      bridge: JSON.parse(provider1).bridge,//"https://bridge.walletconnect.org", // Required
      session: JSON.parse(provider1)
    });
    if (!connector.connected) {
      // create new session
      connector.createSession();
      }
      const transactionParameters: any = {
        to: value, // Required except during contract publications.
        from: this.address, // must match user's active address.
        value: '0x00',
        data: rtoken,
      };
      await connector.sendTransaction(transactionParameters)
      .then((txHash: any) => {
        console.log(txHash);
        Swal.fire({
          icon: "success",
          title: 'send successfully!',
          text: 'Wait for transaction confirmation....',
          html: `<br><a style="color: #089de3" href="${environment.blockchainExploreUrls}/tx/${txHash}" target="_blank">${txHash} () confirmations</a>`,
          customClass: {
            confirmButton: 'btn btn-success'
          },
          showCancelButton: true,
          confirmButtonText: 'CLOSE',
          confirmButtonColor: '#3085d6',
          
        })
        setTimeout(() => {
          location.reload();
      }, 5000);
        
      })
  }catch(err:any){
    console.log(err)
  }

 }else{
  let ethereum: any = window['ethereum']
  const transactionParameters: any = {
    to: value, // Required except during contract publications.
    from: this.address, // must match user's active address.
    value: '0x00',
    data: rtoken,
  };
  await ethereum.request({
    method: 'eth_sendTransaction',
    params: [transactionParameters],
  }).then((txHash: any) => {
    console.log(txHash)
    Swal.fire({
      icon: "success",
      title: 'send successfully!',
      text: 'Wait for transaction confirmation....',
      html: `<br><a style="color: #089de3" href="${environment.blockchainExploreUrls}/tx/${txHash}" target="_blank">${txHash} () confirmations</a>`,
      customClass: {
        confirmButton: 'btn btn-success'
      },
      showCancelButton: true,
      confirmButtonText: 'CLOSE',
      confirmButtonColor: '#3085d6',
    })
    setTimeout(() => {
      location.reload();
  }, 5000);
    // this.confirmTx(txHash, true);
  })
 }

  }
  
  // async approve(amount:any,token:any){
   
  // }
  async callcontractmethods(){
    console.log('hii',this.address,this.contract)
   var amount= await this.contracttokenB.methods.balanceOf(this.address).call()
   this.rtokenBalance =this.web3.utils.fromWei(amount, 'ether')
   var amountBalance= await this.contract.methods.balanceOf(this.address).call()
   this.tokenBalance = this.web3.utils.fromWei(amountBalance, 'ether')
  }

  ngOnInit(): void {
    
    this.web3 = new Web3(
      new Web3.providers.HttpProvider(environment.rpc_network_url)
     );
    // this.contract = new this.web3.eth.Contract(tokencontractABI,environment.tokencontract)
    // this.contracttokenB = new this.web3.eth.Contract(tokencontractBABI,environment.tokencontractB)
    var value = Boolean(localStorage.getItem('address'))
    console.log(value)
    if(value==false){
      this.show =false
    }
    else{
      this.address=localStorage.getItem('address')
      this.address=this.web3.utils.toChecksumAddress(this.address)
      this.show=true
      this.contract = new this.web3.eth.Contract(tokencontract3RABI,environment.tokencontractB,{from:this.address})
    this.contracttokenB = new this.web3.eth.Contract(tokencontract4RABI,environment.tokencontract,{from:this.address})
      this.callcontractmethods()
    }

    
  }
  clear(){
    this.addressForm.reset()
  }
  share() {
    
    if (!this.ngNavigatorShareService.canShare()) {
      alert(`This service/api is not supported in your Browser`);
      return;
    }
 
    this.ngNavigatorShareService.share({
      title: 'My Awesome app',
      text: 'hey check out my Share button',
      url: 'https://developers.google.com/web'
    }).then( (response) => {
      console.log(response);
    })
    .catch( (error) => {
      console.log(error);
    });
  }
  }





  
  



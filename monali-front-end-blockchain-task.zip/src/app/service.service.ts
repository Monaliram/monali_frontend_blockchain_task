import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {  Observable, of, throwError } from 'rxjs';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  public isshowAddress$: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(Boolean(sessionStorage.getItem('showAddress')));
  public tinyAddress$: BehaviorSubject<string> = new BehaviorSubject<string>(sessionStorage.getItem('tinyAddress') || 'Connect');

  constructor() { }
  setisCheckAddress(value: boolean) {
    this.isshowAddress$.next(value);
}
setTinyAddress(value: string) {
  this.tinyAddress$.next(value);
}
}

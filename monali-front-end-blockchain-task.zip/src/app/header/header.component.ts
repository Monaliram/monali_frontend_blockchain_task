import { Component, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';
import WalletConnect from '@walletconnect/client';
import WalletConnectProvider from "@walletconnect/web3-provider";

import tokencontract3RABI from '../Abis/tokencontractABI.json'
import tokencontract4RABI from '../Abis/tokencontractBABI.json'
import Web3 from 'Web3';
import {ServiceService} from '../service.service'
declare let window: any
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  web3:any
  contract:any
  address:any;
  contracttokenB:any
  show:boolean=false
  ismetamask:boolean=false
  istrustwallet:boolean =false
  tinyAddress:any
  constructor(private service:ServiceService) { }
  miniAddress(data: any) {
    let tel = data.toString()
    let str = tel.substr(0, 3) + '....' + tel.slice(-3)
    return str
}
  async metamaskConnect(){
    let ethereum = window['ethereum']
    if (typeof ethereum !== 'undefined') {
      if(ethereum){
        const data = [
          {
              chainId: environment.rpc_chain_id_hex,
              chainName: 'Ethereum Sepolia (Alchemy)',
              nativeCurrency: {
                  name: 'ETH', 
                  symbol: 'ETH',
                  decimals: 18
              },
              rpcUrls: [environment.rpc_network_url],
              blockExplorerUrls: [environment.blockchainExploreUrls]
          }
      ]
      const tx = await ethereum
      .request({ method: 'wallet_addEthereumChain', params: data })
      .catch()
  if (tx) {
      console.log('Please switch network to BNB smart Chain..')
  }
  try{
    ethereum
      .request({
        method: 'wallet_requestPermissions',
        params: [{ eth_accounts: {} }],
      })
      .then(async (permissions:any) => {
        const accountsPermission = permissions.find(
          (permission:any) => permission.parentCapability === 'eth_accounts'
        );
        if (accountsPermission) {
          console.log('eth_accounts permission successfully requested!');
          if(accountsPermission){

      //       const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' })
      // .catch((err:any) => {
      //   if (err.code === 4001) {
      //     // EIP-1193 userRejectedRequest error
      //     // If this happens, the user rejected the connection request.
      //     console.log('Please connect to MetaMask.');
      //   } else {
      //     console.error(err);
      //   }
      // });
      ethereum.request({ method: 'eth_requestAccounts' }).then(async(address: any) =>{
        const account = address;
        console.log(address)
        if(account.length==1){
          this.address =address
          console.log(this.address)
          localStorage.setItem('address', this.address)
          localStorage.setItem('showaddress','true')
          localStorage.setItem('ismetamask','true')
          localStorage.setItem('istrustwallet','false')
          this.tinyAddress = this.miniAddress(this.address)
          localStorage.setItem('tinyaddress',this.tinyAddress)
          this.service.setTinyAddress(this.tinyAddress);
          this.service.setisCheckAddress(true)
          this.ismetamask=true;
          
          this.web3 = new Web3(
            new Web3.providers.HttpProvider(environment.rpc_network_url)
        );
        this.contract = new this.web3.eth.Contract(tokencontract4RABI,environment.tokencontract)
        this.contracttokenB = new this.web3.eth.Contract(tokencontract3RABI,environment.tokencontractB)
          this.show =true;
          console.log(this.show)
          setTimeout(() => {
            location.reload();
        }, 1000);
          
      } 
         
    })
  }
        
  } 
   
    }).catch((error:any) => {
        if (error.code === 4001) {
          // EIP-1193 userRejectedRequest error
          console.log('Permissions needed to continue.');
        } else {
          console.error(error);
        }
      });
       await ethereum.request({ method: 'eth_requestAccounts' })

    }
    catch(err:any){
      console.log(err)
    }
  }
      
  }else{

  }

  }
  disconnect()
  {
    this.show =false
    this.tinyAddress=null
    if(localStorage.getItem('istrustwallet')=="true"){
      
      const provider1 = JSON.parse(JSON.stringify(localStorage.getItem('walletconnect')));
       if(provider1){
            const connector = new WalletConnect({
              bridge: JSON.parse(provider1).bridge,//"https://bridge.walletconnect.org", // Required
              session: JSON.parse(provider1)
            });
            connector.killSession();
          }
    }
      localStorage.removeItem('address')
      localStorage.setItem('showaddress','false')
      localStorage.removeItem('tinyaddress');
      this.service.setTinyAddress('Connect')
      localStorage.removeItem('tinyaddress');
      localStorage.removeItem('showaddress');
      localStorage.removeItem('istrustwallet');
      localStorage.removeItem('address');
      this.service.setisCheckAddress(false)
      // setTimeout(() => {
        location.reload();
    // }, 1000);
  }
  async walletConnect(){
    const provider1 = new WalletConnectProvider({
       rpc: {
      [environment.rpc_chain_id]: environment.rpc_network_url
    },
    chainId: environment.rpc_chain_id 
  })
  try{
    provider1.enable();
    this.web3 = new Web3(provider1 as any)
    window.w3 = this.web3
    var account = await this.web3.eth.getAccounts();
    var account1 = account[0];
    this.address = this.web3.utils.toChecksumAddress(account1);
    localStorage.setItem('address',this.address)
    localStorage.setItem('showaddress','true')
    this.service.setisCheckAddress(true)
    this.istrustwallet=true;
    localStorage.setItem('istrustwallet','true')
    localStorage.setItem('ismetamask','false')
    this.tinyAddress = this.miniAddress(this.address)
    localStorage.setItem('tinyaddress',this.tinyAddress)
    this.service.setTinyAddress(this.tinyAddress);
    this.service.setisCheckAddress(true)
    this.show =true;
    this.web3 = new Web3(
      new Web3.providers.HttpProvider(environment.rpc_network_url)
  );
  this.contract = new this.web3.eth.Contract(tokencontract3RABI,environment.tokencontractB,{from:this.address})
  this.contracttokenB = new this.web3.eth.Contract(tokencontract4RABI,environment.tokencontract,{from:this.address})
    setTimeout(() => {
      location.reload();
  }, 1000);
  }
  catch{

  }
  
  }
  ngOnInit(): void {
    this.web3 = new Web3(
      new Web3.providers.HttpProvider(environment.rpc_network_url)
  );
    // this.contract = new this.web3.eth.Contract(tokencontractABI,environment.tokencontract)
    // this.contracttokenB = new this.web3.eth.Contract(tokencontractBABI,environment.tokencontractB)
    var value = Boolean(localStorage.getItem('showaddress'))
    if(value==false){
      this.show =false
    }
    else{
      
      this.address=localStorage.getItem('address')
      this.address=this.web3.utils.toChecksumAddress(this.address)
      this.show=true
      this.contract = new this.web3.eth.Contract(tokencontract3RABI,environment.tokencontractB,{from:this.address})
    this.contracttokenB = new this.web3.eth.Contract(tokencontract4RABI,environment.tokencontract,{from:this.address})
    }
    var value2 =localStorage.getItem('tinyaddress')// this._AuthService.getTinyAddress() //
  //console.log('value2:', value2);
  if (value2 == null) {
      this.tinyAddress = 'N/A'
  } else {
      this.tinyAddress = value2;
  }
  }

}

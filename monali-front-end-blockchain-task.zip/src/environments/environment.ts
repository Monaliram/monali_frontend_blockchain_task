// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  rpc_chain_id:11155111,
  rpc_chain_id_hex:'0xAA36A7',
  rpc_network_url:'https://eth-sepolia.g.alchemy.com/v2/4OqokkmbPSmOttUuhYgeSxKrx9PH2Wvv',
  blockchainExploreUrls:'https://sepolia.etherscan.io',
  tokencontract:'0x9cA9A8f02e77569A69babAF0dDe0987BE7b525D5',
  tokencontractB:'0xc1D95464215F484027D58e5f6F700D3f1C167fc9'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.

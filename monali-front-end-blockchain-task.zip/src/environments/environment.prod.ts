export const environment = {
  production: true,
  rpc_chain_id:11155111,
  rpc_chain_id_hex:'0xAA36A7',
  rpc_network_url:'https://eth-sepolia.g.alchemy.com/v2/4OqokkmbPSmOttUuhYgeSxKrx9PH2Wvv',
  blockchainExploreUrls:'https://sepolia.etherscan.io',
  tokencontract:'0x9cA9A8f02e77569A69babAF0dDe0987BE7b525D5',
  tokencontractB:'0xc1D95464215F484027D58e5f6F700D3f1C167fc9'

};
